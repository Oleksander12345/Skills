---
name: distributed-systems
description: Reason about or implement cross-process state, partial failure, retries, concurrency limits and consistency guarantees. Excludes local algorithms, ordinary synchronous CRUD and standalone concept definitions.
---

# Distributed systems

Identify authoritative state, participants, ownership, transaction boundaries, and which failures can occur independently. Specify the required consistency, staleness tolerance, ordering and availability for the actual operation; avoid slogans about CAP as a design substitute.

Trace timeout-after-commit, duplicate delivery, worker crash, unavailable dependency and recovery. A timeout is an unknown outcome, not proof of failure. Use stable operation identity and an explicit reconciliation path where effects cannot be atomically committed together. Define the lifetime and scope of deduplication. Do not promise exactly once from a queue, lock or retry alone.

Set an end-to-end deadline and retry budget. Coordinate retry ownership to avoid multiplicative attempts across layers. Retry only appropriate failures with bounded backoff and jitter; preserve idempotency. Bound concurrency, queues and resource usage. Apply backpressure, admission control or load shedding when necessary rather than buffering indefinitely.

Treat leases, caches, replicas and clocks as fallible. State expiration, invalidation, stale-reader and split-owner behavior when used. For correctness-critical exclusive work, examine fencing or equivalent stale-owner protection instead of assuming a lease is permanent ownership.

Prefer the simplest design meeting the required failure semantics. Add orchestration, compensation, durable event handoff or specialized coordination only for a concrete boundary problem. Compensation is a business action and may fail; it is not a universal rollback.

Verify invariants under interleavings and fault scenarios in isolation. Explain remaining uncertainty, operational signals and recovery steps without causing real outages. Do not expand a local feature into a distributed architecture unnecessarily.
