---
name: frontend-engineering
description: Implement or refactor nontrivial interactive state, forms, asynchronous data or component responsibilities. Excludes cosmetic edits, static copy changes and dedicated visual-design work.
---

# Frontend engineering

Trace the user action through state, requests, rendering, persistence and navigation. Respect the existing platform and component conventions; do not introduce a new state framework or rendering model without a demonstrated need.

Give each piece of state one owner and a clear lifetime. Derive values rather than storing synchronized duplicates when practical. Distinguish server state, editable drafts and transient UI state. Define conflict/reset behavior on navigation, refresh and concurrent updates.

Split components by cohesive responsibility and change boundaries, not arbitrary line counts. Assess nested conditions, coupled state transitions, effect chains, hidden mutations and prop interactions. Prefer explicit data flow and focused operations over layers of wrappers. Extract shared behavior only when semantics actually match; avoid a universal component with many boolean modes.

Name state, events and callbacks for their actual meaning and effects; distinguish a local draft update from persistence or submission. Make ambiguous mode flags and same-typed positional arguments clear using existing conventions; do not ban boolean data or create configuration objects solely to reduce parameter count. Comments should preserve non-obvious interaction, accessibility or timing constraints rather than repeat the code. Keep refactoring scoped to the changed flow.

Model loading, empty, error, success and partial-result behavior where the flow needs them. Protect against stale asynchronous results and unintended duplicate actions. Cleanup subscriptions and resources, preserve cancellation semantics, and make optimistic updates reversible when appropriate. A client-side permission check cannot replace server authorization.

Preserve semantic controls, accessible names, keyboard operation, focus, and meaningful error feedback. Prefer native platform behavior when it fits. Consider render work, data volume, memory and network costs before introducing memoization or caching; measure the suspected bottleneck.

Verify the changed interaction and its important failure path using existing tests or browser tools. State what was actually exercised. Cosmetic edits do not require an architectural redesign or a full journey suite.
