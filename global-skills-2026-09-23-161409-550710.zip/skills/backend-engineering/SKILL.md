---
name: backend-engineering
description: Implement or refactor nontrivial server-side business logic, resource lifecycles and I/O boundaries. Excludes mechanical edits, conceptual questions and standalone architecture or security audits.
---

# Backend engineering

Trace the existing request and job paths, domain invariants, dependencies, and error contracts. Follow the project's idioms; do not impose an object-oriented or functional rewrite on a working design.

Keep cohesive business rules understandable and independently testable. Separate deterministic calculation from orchestration and external effects where that clarifies behavior. Validate untrusted input at boundaries and enforce authorization at the operation that accesses protected resources.

Judge function complexity by nested decisions, independent execution paths, hidden state, side effects, parameter interactions, and difficulty naming its responsibility. Line count is a signal, not a quota. Prefer guard clauses and explicit state transitions when they clarify control flow. Extract meaningful operations with clear contracts; do not turn one understandable function into a chain of trivial wrappers. Reuse actual shared rules, not merely similar-looking code.

Name operations and values for their domain meaning, units and observable effects. A predicate-looking check must not unexpectedly reset state or perform I/O. Prefer explicit dependencies to hidden state merely to reduce argument count. Keep familiar short names in clear local contexts. Make ambiguous boolean modes or same-typed positional arguments understandable through the project's naming or parameter conventions; group values only when they form a real concept. Preserve cohesive orchestration and atomic check-and-change operations even when they contain several steps or return a result. Keep low-level integration details out of the business narrative when a meaningful boundary helps.

Comments should explain non-obvious reasons, invariants and constraints, not narrate obvious syntax. Update affected comments with behavior; avoid unrelated naming or comment churn.

Use SOLID as decision criteria: cohesive reasons to change, dependencies pointing toward stable policy, narrow consumer contracts, and replacements that preserve behavior. Introduce abstractions at real substitution or testing boundaries. Avoid speculative factories, interfaces per class, deep inheritance, or clever generalization. Use objects when they protect state and invariants; simple functions and data can be sufficient.

Bound work, concurrency and resource lifetime. Handle deadlines, cancellation, cleanup, partial failure and ambiguous external results. Transactions protect only their actual participants; remote side effects need explicit retry/idempotency/recovery semantics. Preserve observable contracts during refactoring.

Verify changed rules and meaningful failure paths with existing tooling. Use complexity tools already adopted by the project as evidence; do not invent universal numeric limits or install a new framework just to enforce style.
