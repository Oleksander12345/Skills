---
name: api-integration-design
description: Design or change external API contracts, webhooks or third-party integration behavior. Excludes ordinary internal function edits and conceptual protocol questions.
---

# API and integration design

Identify consumers, trust boundaries, operation semantics, ownership and compatibility obligations. Reuse established contracts and naming; select request/response, streaming or event delivery based on interaction and failure needs.

Specify input validation, authorization scope, errors, pagination, cancellation and response behavior only where relevant. Make resource bounds explicit: payload sizes, page sizes, timeouts and rate limits. Do not expose secrets or unnecessary internals in errors. Distinguish authentication from permission to access the requested object or tenant.

For retried writes, define operation identity, idempotency scope/lifetime, payload mismatch and concurrent duplicate behavior. Explain the outcome when the server commits but the response is lost. Bound retries within a total deadline; honor provider contracts without retrying every error.

Verify incoming webhook authenticity using the provider's documented signed representation, often exact raw bytes; parsing and reserialization may change it. Follow the actual algorithm and key rotation contract rather than inventing crypto. Validate replay/freshness rules and deduplicate operations. Handle out-of-order events and durable acceptance separately from business processing.

Plan additive and breaking evolution, default behavior, unknown values and deprecation according to existing consumers. Keep adapters cohesive; translate provider-specific failures at the boundary while preserving useful diagnostics. Do not leak a vendor's model throughout unrelated domain logic.

Verify contracts with representative successful, invalid, unauthorized, duplicate and partial-failure cases. Use current provider documentation for concrete implementation. Avoid live side effects, sending messages or changing third-party resources without the required authorization.
