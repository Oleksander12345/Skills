---
name: documentation-adr
description: Write or update requested engineering documentation or record a consequential architectural decision. Excludes routine edits that need no durable decision record and requests solely for implementation.
---

# Engineering documentation and decisions

Identify the reader, question and authoritative sources before writing. Inspect the actual implementation or agreed decision. Distinguish current behavior, proposed behavior, assumptions and unverified claims. Do not invent commands, file paths, benchmarks or operational guarantees.

Update the existing canonical document when it serves the purpose. Use a README for getting started, a runbook for repeatable operations and an ADR for a consequential decision with alternatives and lasting trade-offs. Do not generate all three or record a typo fix as architecture.

An ADR should explain the concrete context and constraints, decision, credible alternatives, reasons, consequences and conditions for reconsideration. Include status, scope and recovery/rollback implications when meaningful. Record unknowns explicitly; hypothetical future scale is not a measured fact. Keep the depth proportional to the decision.

For procedures, provide prerequisites, exact commands grounded in the environment, expected outcomes, failure handling and permission boundaries as needed. Mark destructive or externally visible steps clearly without inventing additional approvals. Verify runnable examples and links where feasible; disclose when execution was unavailable.

For code comments, explain non-obvious intent, domain constraints, invariants, concurrency hazards or workarounds. Keep them accurate as behavior changes; avoid paraphrasing obvious code or duplicating volatile facts owned elsewhere. A useful TODO states the actual limitation and resolution condition, with a tracking reference when one exists. Public contracts should describe meaningful inputs, outputs, errors and examples when needed. Remove obsolete commented-out implementations only after checking their purpose and recoverability; preserve required license notices and useful examples. Follow the project's documentation format rather than banning markup categorically.

Prefer concise explanations that remain useful to someone outside this conversation. Avoid copying a general tutorial into project docs or duplicating details that will drift. Link to maintained references for implementation-specific facts. Preserve the audience's professional tone and the user's requested format.
