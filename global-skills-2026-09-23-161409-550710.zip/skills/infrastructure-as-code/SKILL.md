---
name: infrastructure-as-code
description: Create or change Terraform/OpenTofu infrastructure, managed state, resource lifecycle and drift. Excludes application deployment manifests, ordinary runtime operations and conceptual cloud questions.
---

# Infrastructure as code

Inspect the existing tool/version, providers, state backend, workspace/account/region, resource addresses and delivery process. Establish which configuration and team own each resource; do not adopt, duplicate or move ownership by assumption. Use current tool/provider documentation for concrete syntax and lifecycle behavior.

Design module boundaries around cohesive ownership and lifecycle. Parameterize real differences between consumers, not every literal. Follow existing version constraints and dependency locks; make upgrades intentional. A module refactor can change resource addresses: preserve existing identity with supported move/import mechanisms when recreation is not intended. Inspect the resulting plan instead of assuming a textual rename is harmless.

Review create, update, replace and destroy actions against the request, including dependent resources, downtime, data retention and privilege changes. Determine state locking and concurrent-writer behavior before mutation. Treat state and plan files as sensitive; display redaction does not imply secrets are absent from storage. Avoid logging or committing them.

Use available formatting and validation, then inspect a plan for the intended environment when access permits. Validation alone does not establish the actions a real plan will take. A plan is contextual evidence, not a promise about a later changed configuration or environment. Report unavailable checks explicitly.

For authorized apply/import/state changes, retain recovery options and reconcile partial completion with actual resources before retrying. Reverting configuration does not necessarily restore data or undo cloud effects. Keep execution within existing authorization; do not infer apply permission from a request to prepare configuration, or ask again for already-authorized work.

Useful Terraform references: [resource moves](https://developer.hashicorp.com/terraform/language/modules/develop/refactoring), [sensitive data](https://developer.hashicorp.com/terraform/language/manage-sensitive-data). Consult the chosen engine's documentation rather than assuming Terraform and OpenTofu versions behave identically.
