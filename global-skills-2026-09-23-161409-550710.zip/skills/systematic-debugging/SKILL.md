---
name: systematic-debugging
description: Investigate software failures with uncertain causes, flaky tests, regressions, or unsuccessful fixes. Excludes conceptual explanations and obvious mechanical edits with an already established cause.
---

# Systematic debugging

Establish expected and observed behavior, the failing input, environment, and recent relevant changes. Obtain a minimal reproduction or inspect available logs and code. If execution is unavailable, distinguish a plausible hypothesis from a reproduced cause.

Trace the failing value or operation through shared helpers and every affected caller, including scheduled jobs and background workers. Search callers before editing a shared function. Inspect boundaries, state transitions, and error handling rather than patching only the reported entry point.

Choose the most discriminating next observation or experiment for the leading hypothesis. Change one explanatory variable at a time where practical. If evidence contradicts the hypothesis, revise it instead of accumulating speculative patches. Do not repeat an unchanged failed experiment.

For concurrency or external side effects, examine interleavings and crash windows. Atomic database state does not prove an external operation happened once; timeouts may hide successful remote work. Establish retry, idempotency, and reconciliation behavior before promising delivery guarantees.

Fix the cause at the narrowest shared boundary that covers affected callers, preserving contracts. Add or update a focused regression check that fails on the original defect where feasible. Run relevant existing checks and inspect the result. Avoid exposing secrets in diagnostic output and avoid destructive production experiments.

Report the evidence, change, actual checks, and remaining uncertainty. If blocked by missing access or inputs, state the precise missing evidence and next safe step; do not claim a fix has been verified.
