---
name: software-design
description: Choose representations, algorithms or state ownership for local libraries and CLI tools when a consequential design decision is needed. Excludes mechanical edits, routine work under an established design, UI/server-specific work and system architecture.
---

# Software design

Start from callers, observable behavior, invariants and realistic workload constraints. Preserve project idioms; resolve the consequential choice without redesigning unrelated code.

Choose representation and algorithm together. Account for input size, operation frequency and output size, plus time and space costs of preprocessing, retained indexes and temporary allocations. Preserve required ordering, duplicates, equality, identity and ownership when changing collections or caches. A faster lookup is not an improvement if it changes semantics or exceeds the memory budget.

Keep mutable state ownership and valid transitions clear. Add abstractions only for a present invariant, ownership boundary or real variation; similar syntax alone does not establish shared policy. Use existing callers or agreed changes to judge boundaries, not invented future features.

Check runtime semantics relevant to correctness: numeric range and precision, aliasing, iteration and mutation. Define valid state after failure or cancellation and required cleanup. Async scheduling alone does not make CPU work parallel; choose concurrency from the workload and runtime, with bounded resources.

Verify consequential semantics against independently derived examples and relevant boundary cases. Scale checks to the changed behavior and risk; a design choice alone does not require a new test suite or benchmark. Distinguish complexity reasoning from measured performance when reporting trade-offs.
