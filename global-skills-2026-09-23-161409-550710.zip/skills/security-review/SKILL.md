---
name: security-review
description: Perform a requested security review or assess a changed trust boundary involving access control, untrusted execution, secrets or external destinations. Excludes routine edits with no security impact.
---

# Security review

Bound the review to the changed assets, entry points, privileges and trust boundaries. Trace attacker-controlled input to sensitive reads, writes, execution and outbound requests. Establish realistic attacker capability; do not invent an exploit or label every concern critical.

Check authentication separately from object-, tenant- and action-level authorization. Inspect alternate paths, caches, background work and defaults that can bypass the control. Fail closed where authorization or trust cannot be established.

Choose checks from the actual data flow: injection at interpreters, output encoding at rendering boundaries, request forgery, unsafe deserialization, path traversal, secret exposure, session handling or dependency risk. Treat validation, canonicalization and encoding as distinct operations. Use vetted cryptographic facilities and documented protocols, not homemade algorithms.

For user-controlled outbound requests, an initial scheme check is insufficient. Evaluate destination and port policy, name resolution, redirects, rebinding and internal/metadata access in the actual client and network. Prefer constrained destinations and enforced egress boundaries where suitable. Apply resource/time limits and avoid forwarding credentials across trust boundaries.

Verify suspected issues through code evidence and isolated authorized tests. Never attack live services, extract secrets, or weaken safeguards merely to demonstrate impact. Give each actionable finding its trigger, affected boundary, consequence, evidence and focused fix; separate confirmed defects from hypotheses.

Check a denied case as well as an allowed one. State review scope and untested assumptions. No findings does not establish that the whole system is secure. Do not turn every ordinary implementation into a full audit.
