# Paired behavioral evaluation

Read when evaluating new or substantially changed behavioral guidance.

1. Select a representative task and a nearby non-triggering task. Add a failure or pressure case only when it tests a real risk. Define observable success criteria before running either variant.
2. Run a baseline without the candidate and a separate run with it. Keep model, effort, task, inputs, tools, and permissions equal. Use fresh contexts; neither run sees the other's answer or the author's proposed solution. A subagent that inherits this conversation is not a clean baseline.
3. Use isolated fixtures without external side effects. Delegation requires authorization under the active session rules; paid API use and production actions require their own authorization.
4. Inspect correctness, task completion, scope drift, unnecessary questions, tool calls, and elapsed time. Record input, cached input, output tokens, and cost only if available. Missing telemetry is unknown, not zero. Prompt length alone is not total usage.
5. One pair is exploratory evidence, not a reliable improvement percentage. Repeat ambiguous or consequential comparisons within an agreed budget; do not run an expensive fixed repetition count automatically.
6. Keep the smallest revision supported by the results. If the baseline already succeeds, do not claim a quality gain. If the candidate adds work without demonstrated benefit, trim it, narrow its trigger, or leave it uninstalled. Report limitations honestly.

## Discovery and coexistence

Separate instruction quality from discovery. Use realistic requests without naming a skill; inspect which skill bodies and conditional references were actually read. An explicit-invocation run can isolate the content when discovery fails, but does not validate automatic selection. The agent's self-report alone is not routing evidence.

Include a nearby non-triggering task and a meaningful overlap with an installed personal or plugin skill. Judge the completed result, scope and unnecessary work rather than demanding one exact skill combination. No mandatory chains or new approvals should appear merely because several skills apply.

Compare the current set against the same set plus the candidate change. Record available environment/model/tool details and unavoidable contamination from inherited instructions. Keep evaluator criteria and held-out cases out of the implementation prompt. Prefer correcting a failed boundary over expanding a general checklist; stop when the scoped acceptance criteria are met.
