---
name: writing-effective-skills
description: Create, adapt, or evaluate personal engineering skills when the user requests reusable agent instructions. Excludes ordinary coding, one-off prompts, and document templates.
---

# Writing effective skills

Build instructions around a demonstrated failure, a fragile workflow, or a concrete user preference. A skill is useful when it improves decisions enough to justify its added context and actions.

## Define the improvement

Inspect the existing skill and relevant project instructions before editing. Reuse useful material; check its license before copying or distributing it. Prefer editing a matching personal skill over adding an overlapping one. Leave bundled and plugin-cache files intact.

Identify the intended task, desired observable behavior, and a nearby task that should not trigger the skill. Infer these from the request when possible. Ask only when missing information changes the design. If the request is speculative, explain that benefit is unproven; do not invent a failure to justify a skill.

## Write the smallest useful guidance

- Give the description a specific trigger. Avoid activation on every conversation or every mention of a technology.
- Include decision criteria, relevant evidence, and concrete failure modes. Do not write a textbook or a checklist of everything a senior engineer knows.
- Scale work to the task: no universal requirement for planning, TDD, delegation, full test suites, or approval before reversible work.
- Preserve existing project conventions and the user's scope. A skill does not grant permission to publish, deploy, or contact others.
- Keep essential guidance in SKILL.md. Put substantial conditional detail in referenced files with clear reading conditions; never load them all by default.
- Avoid chains of mandatory skills. Use available tools and existing project checks where they fit.
- Keep automatic discovery scoped to relevant requests unless the user asks for explicit-only invocation.

Use the installed skill-creator's initializer or validator when helpful; do not copy its formatting manual into the new skill. Do not change unrelated settings or install dependencies merely to author instructions.

## Verify proportionally

For a small wording or metadata edit, validate structure, paths, trigger boundaries, and changed meaning. For substantial behavioral guidance, use the paired evaluation in [evaluation.md](evaluation.md) when authorized execution is available. If it is unavailable or too costly, deliver the draft and state that behavioral benefit remains untested.

Check observable results, not whether the answer repeated prescribed headings. Fix the specific failure found; do not add universal rules for speculative problems.

Report what changed, checks actually performed, and any unmeasured claims. Distinguish structural validity from behavioral benefit and measured savings from estimates. Keep or expand the skill only when real use or evaluation supports it.
