# Prompts inside applications

Read for application prompts and reusable templates. Improve the existing integration; this does not imply a provider, framework or architecture migration.

## Inspect the actual contract

Trace inputs through template rendering, message roles, retrieved context/history, model call, tools, output parsing and downstream decisions. Establish the actual provider, model/version, API/SDK and generation settings before relying on their semantics. Inspect callers, schemas and failing examples; a prompt string alone may omit the cause.

Preserve variable names/types, escaping, message roles, output keys/enums, null/abstention behavior and tool contracts unless their change is intentional and compatible with callers. Render representative requests to check missing variables, literal braces, quotes, Unicode, empty values and truncation where relevant. Do not promote interpolated user text into trusted instructions. Keep sensitive values out of fixtures and logs.

Distinguish unclear instructions from missing/stale retrieval, discarded history, token truncation, parser defects or unavailable tools. Fix the responsible layer within scope; report a required change outside it rather than hiding the problem with stronger wording.

## Choose guidance for the task

State the operation, evidence to use, decision boundaries and output contract. Add a small, diverse set of correct examples when they resolve observed ambiguity; match the real schema and include meaningful abstention cases. Keep examples separate from final evaluation data. Avoid redundant rules or an exhaustive catalogue of imagined failures.

For extraction/classification, define labels, ambiguity and missing information without inventing values to satisfy a required field. For RAG, preserve source identifiers and provenance; require support from available evidence and specify what to do when evidence is insufficient or conflicting. Check retrieval quality separately from answer faithfulness. More context cannot recover information never retrieved.

For tool use, align instructions with actual tool names, argument schemas, results and failure behavior. A model-proposed call is not authorization: permissions and argument validation belong at the execution boundary. Do not grant tools or broaden access merely to improve a prompt.

## Enforce what code can enforce

Separate trusted instructions from user, document and tool-result content using the provider's supported roles and explicit data boundaries. Delimiters improve readability but do not guarantee resistance to prompt injection. Test hostile content where it can affect decisions; preserve code-enforced access and side-effect constraints.

For machine-consumed results, use supported structured-output/tool schemas when appropriate, keeping them aligned with the parser. JSON syntax, schema validity and semantic correctness are separate properties. Handle the actual API's refusal, incomplete/truncated output and transport failures. Validate business constraints and unknown values in code; do not silently coerce invalid output into a successful result. Bound any existing repair/retry path and avoid repeating external effects.

## Verify and keep changes reproducible

Check rendering and consumer compatibility deterministically, then use [evaluation.md](evaluation.md) for model behavior. A mock proves integration properties, not instruction following. Retain the original prompt and record prompt/model/settings/data versions for meaningful comparisons and recovery. Use the project's existing versioning and release process.

Consider input/output size, latency and cost against actual requirements. Cache-friendly stable prefixes and context ordering depend on the provider and workload; preserve meaning and test trade-offs. Do not assume temperature zero guarantees repeatability, add a chain of calls without evidence, or buy infrastructure to tune a prompt.

Sources: [OpenAI prompt engineering](https://developers.openai.com/api/docs/guides/prompt-engineering), [structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs), [untrusted-input boundaries](https://developers.openai.com/api/docs/guides/agent-builder-safety), [Gemini structured output](https://ai.google.dev/gemini-api/docs/generate-content/structured-output), [Anthropic context engineering](https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents). Provider examples and product-specific settings are not universal requirements; verify current details for the integration.
