# Evaluate a prompt change

Read for behavioral comparisons and prompt optimization. Use existing evaluation tooling; do not create a benchmark platform for a small wording change.

Inspect representative inputs, outputs and traces to identify concrete failure modes. With the user/domain owner, clarify ambiguous success criteria; model-written labels are proposals, not established truth. Missing context or bad labels may explain failure better than the prompt. If only synthetic examples exist, label that limitation.

Choose task-specific checks before comparing revisions: extraction values, correct classification, evidence support, permitted tool/argument selection or successful downstream behavior. Formatting alone is insufficient. Include normal cases, known failures and relevant nearby cases that must not regress; use missing/conflicting evidence, long inputs or hostile text when they test an actual boundary.

Keep development examples and a held-out check separate. Do not copy held-out answers into the prompt or repeatedly tune against the test set while calling it unseen. Compare original and candidate under matched model/version, settings, tools, data/retrieval and limits; record intentional differences. Repeat only when variability could change the decision, within available authorization and budget. A single favorable response cannot establish improvement.

Prefer deterministic assertions for exact contracts. For subjective outputs, use a task-specific rubric and inspect failures. Validate any LLM judge against domain-reviewed examples, watch for order/verbosity bias, and investigate disagreements; a second model's approval is not ground truth. If criteria change after reviewing results, record that and reassess both variants consistently.

Report outcomes by relevant failure category, remaining regressions and measured latency/token/cost trade-offs where available. Unknown telemetry is not zero. Keep the smallest change supported by results; do not claim a gain when the baseline already succeeds. If model execution is unavailable, deliver the code/static checks and concrete eval cases, explicitly leaving model-quality claims unverified. Do not use hidden credentials, spend money or run production traffic without existing authorization.

Sources: [OpenAI evaluation guidance](https://developers.openai.com/api/docs/guides/evaluation-best-practices), [Anthropic success criteria](https://platform.claude.com/docs/en/test-and-evaluate/develop-tests), [Hamel Husain and Shreya Shankar on error analysis](https://hamel.dev/blog/posts/evals-faq/why-is-error-analysis-so-important-in-llm-evals-and-how-is-it-performed.html) and [limits of automatic optimization](https://hamel.dev/blog/posts/evals-faq/should-i-stop-writing-prompts-manually-in-favor-of-automated-tools.html).
