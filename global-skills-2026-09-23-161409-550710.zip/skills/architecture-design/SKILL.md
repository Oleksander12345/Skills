---
name: architecture-design
description: Evaluate consequential system boundaries, integration patterns, consistency or scaling decisions, and proposed architecture changes. Excludes ordinary component edits and changes with an established local design.
---

# Architecture design

Ground decisions in the existing system, team capacity, workload, latency and availability needs, data ownership, and deployment constraints. Distinguish measured facts, explicit requirements, and estimates. Missing scale figures are not permission to invent them.

Describe the current request and data flow before proposing a replacement. Compare the simplest viable option with alternatives that solve a demonstrated limitation. Justify service boundaries by independent ownership, isolation, deployment, or scaling needs; fashion is not a requirement.

Trace the important failure path: caller times out after a write, worker crashes, event duplicates or arrives late, dependency stalls. Identify the source of truth, transaction boundary, idempotency scope, ordering requirements, and recovery mechanism where relevant. A queue does not make side effects exactly once. Bound retries and concurrency; consider backpressure and cancellation rather than multiplying retries across layers.

Choose synchronous or asynchronous work, transport, storage, and caching from those requirements. State consistency and staleness implications, including cache invalidation and tenant isolation when affected. Do not add every distributed-systems pattern preemptively.

Present the decision, contextual reasons, main trade-offs, and a feasible transition with compatibility, observability, and rollback limits. Label assumptions and the evidence that would justify a more complex design. Use an ADR or diagram when requested or when it materially clarifies the decision. Architecture advice does not authorize deployment or infrastructure spending.
