---
name: incident-debugging
description: Triage an active service incident or production degradation with user impact. Excludes ordinary local debugging, retrospective documentation and speculative reliability improvements.
---

# Incident debugging

Establish impact, start time, affected operations, severity indicators and available access. Distinguish facts from reports and hypotheses. Preserve a concise timestamped timeline; do not wait for a complete root cause before considering safe mitigation.

Start with read-only evidence when available: recent changes, error/latency/saturation signals, traces, dependency health, queue lag and resource exhaustion along the affected path. Compare affected and unaffected cohorts to narrow hypotheses. A full pool can be an effect of slow queries or a dependency, not the root cause.

Choose discriminating observations and prioritize containment that preserves data and recovery options. Evaluate rollback compatibility, load reduction, feature isolation or capacity adjustments against the current state. Do not blindly restart everything, purge queues or multiply retries.

Separate proposed mitigation from authorized execution. Urgency does not create access or permission for destructive actions, live writes or external messages. If authority is missing, continue useful analysis and present the specific action and expected risk for approval. Avoid broad requests that block all progress.

After an authorized change, observe user-facing recovery, backlog drainage and delayed side effects; a green process or falling error count alone may hide dropped work. Preserve diagnostic evidence and protect credentials and personal data.

Report impact, verified observations, actions actually taken, remaining uncertainty and the next decision. Keep durable corrective work separate from urgent stabilization. After recovery, use a blameless causal explanation and a targeted regression or operational check instead of assigning an unsupported root cause.
