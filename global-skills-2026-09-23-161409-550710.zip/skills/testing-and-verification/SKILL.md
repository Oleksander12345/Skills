---
name: testing-and-verification
description: Choose tests and verify nontrivial implementation changes, especially permissions, persistence, concurrency or integration boundaries. Excludes routine prose/cosmetic edits and standalone conceptual questions.
---

# Testing and verification

Read the change, affected callers, and existing test/build commands. Select checks from the changed behavior and failure risk rather than running every available suite. Follow explicit repository requirements. For trivial text changes, inspection may be sufficient.

Use unit tests for deterministic local rules, integration tests for real storage or service boundaries, contract tests for shared interfaces, and E2E for essential user journeys when those layers are affected. Prefer existing test infrastructure. Do not add frameworks or broad mocking merely to increase test counts.

A regression check must distinguish the old defect from the fix. For authorization, exercise a prohibited cross-user or cross-tenant case and a permitted case through the relevant boundary. For concurrency or retries, exercise duplicates and failure windows. Do not mock away the property being verified. Include edge cases that could alter the outcome, not exhaustive imaginary combinations.

Derive important expected results from the requirement, contract or an independently worked example, not a copy of the implementation's algorithm. When changing an existing test expectation, establish whether the contract changed or the test is accepting a regression. Assert the relevant result and side effect, not just successful execution.

Run the smallest relevant checks first. Broaden only for requirements or unresolved risk: typecheck, lint, build, integration, browser flow, or runtime smoke checks when they provide distinct evidence. Never equate compilation with working runtime behavior. If UI behavior changed, inspect the actual affected flow when tooling is available; don't mandate browser runs for unrelated work.

Read exit status and substantive output. Record skipped, failing, and unavailable checks with their implications; a passing mock-based unit test cannot substitute for an unavailable integration test. Do not install credentials, spend money, mutate production, or weaken tests to obtain a green result.

Before claiming completion, compare the final diff and relevant new files with the requested behavior; check omissions and unintended changes. Distinguish implemented behavior from verified behavior. State what ran and what remains unverified without repeating checks solely for ceremony.
