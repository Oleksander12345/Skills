---
name: code-review
description: Review a requested diff, pull request or implementation for actionable defects and regressions. Excludes ordinary implementation requests that do not ask for review and purely stylistic rewriting.
---

# Code review

Establish the requested scope and read applicable repository guidance. Inspect the diff together with affected callers, contracts, and tests. Focus on introduced or exposed defects; separate pre-existing issues when relevant. Do not modify code unless fixes are requested or already authorized.

Trace concrete inputs through the changed behavior. Prioritize correctness, authorization and tenant isolation, data integrity, concurrency, failure handling, and compatibility. Examine performance when the affected path and workload support a plausible regression. Evaluate architecture and maintainability only where they have a concrete consequence, not to enforce personal taste.

Evaluate complexity through control-flow paths, nesting, hidden state, side effects, cohesion and dependency direction. Function length alone is not a defect. Flag fragmentation, speculative abstraction or inheritance only with a concrete comprehension, correctness or change-cost consequence. SOLID and OOP are useful design tools, not mandates for interfaces and classes everywhere.

Check for misleading names, units, parameter ordering and undocumented effects where they can cause misuse. A query-like name that conceals mutation deserves scrutiny; an atomic mutation returning its result is not inherently a defect. Do not split check-and-change operations into race-prone separate calls for stylistic purity. Flag stale comments or missing non-obvious constraints with concrete consequences, not a quota of naming nits. Preserve established error-handling idioms rather than universally preferring exceptions, and do not replace clear branching with polymorphism without a real benefit.

Look beyond passing tests: determine whether mocks bypass the boundary at risk and whether failure/negative cases exist. Validate a suspected issue with a focused check when feasible and safe. Static reasoning is valid evidence if the triggering conditions and code path are explicit; don't present it as a runtime reproduction.

Report only actionable findings with the trigger, impact, supporting code location when available, and a focused correction. Use verified file paths and line numbers; never invent them. Rank severity by realistic impact and reach, and disclose uncertainty. Do not duplicate the same root cause across multiple findings.

If no actionable defect is found, say so with the scope and verification limits. Do not fabricate findings to fill a quota or claim the system is secure because a limited review found none. Provide a brief summary rather than an unsolicited rewrite, exhaustive checklist, or mandatory extra reviewer chain.
