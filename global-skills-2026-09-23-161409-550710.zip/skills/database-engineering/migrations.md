# Database changes

Inspect the current schema, application reads/writes, migration tooling, data size, and deployment process. Confirm the engine and version before prescribing engine-specific SQL or lock guarantees. Without them, give a conditional conceptual plan and ask only for details needed for executable changes.

Define invariants and ownership first. Inspect or request evidence for nulls, duplicates, orphaned references, skew, and affected row counts. Do not guess how conflicting records should be merged or deleted; that is a domain decision. Use suitable database constraints for invariants where possible, with meaningful application error handling.

For live changes, account for old and new application versions together. Stage compatible schema expansion, application writes, bounded resumable backfill, validation, enforcement, and removal of obsolete structure as needed. Not every small migration needs every stage. Address writes during backfill; a one-time cleanup alone cannot prevent new violations.

Consider locks, transaction duration, index-build behavior, log/replica load, and failure recovery. Choose batch keys/checkpoints that handle retries and concurrent changes. Inspect query plans and representative workload before claiming an optimization. Avoid claiming zero downtime without engine-specific evidence and an operational plan.

Verify on an appropriate fixture or staging environment, including dirty existing data and interruption/resumption when relevant. Distinguish reversible application rollout from irreversible data loss or schema removal. Explain rollback or roll-forward limits and required recovery safeguards. Reading production metadata does not authorize migrations; act only within the user's actual permissions and scope.
