---
name: database-engineering
description: Design or change data models, transactions, queries, indexes and migrations with integrity, concurrency or scale implications. Excludes routine database usage and local code renames.
---

# Database engineering

Start with domain invariants, data ownership, access patterns, volume and change rate. Identify the authoritative representation and the required consistency. Choose relational, document or key/value organization from those needs and existing constraints; no storage model is universally superior.

Model keys, relationships, uniqueness and lifecycle explicitly. Normalize or duplicate data based on update semantics and read patterns; duplicated state needs ownership and a reconciliation policy. Enforce appropriate invariants at the durable boundary rather than relying solely on a prior application check.

Use ACID precisely: a transaction is only as broad as its participants and isolation guarantees. Atomic commit does not eliminate lost updates, write skew or check-then-write races under every isolation level. Trace concurrent schedules. Choose atomic conditional writes, constraints, optimistic conflict detection or suitable locking/isolation for the actual invariant. Bound transactions and retries; preserve stable operation identity.

For concurrent check-and-change, multi-record invariants or locking/isolation/retry design, read [transactions.md](transactions.md).

A database transaction does not atomically include a remote payment or message. Define durable handoff, idempotency and recovery for external effects. Avoid holding locks across slow remote calls without a justified contract.

Inspect query plans, selectivity, scanned rows, query counts and time/space growth against representative data. Evaluate index order and maintenance costs, pagination stability and lock contention. Add replication, partitioning or sharding only for a supported requirement, with consistency and operational consequences stated.

Confirm engine/version before implementation-specific SQL or guarantees. For schema or large-data rollout, read [migrations.md](migrations.md), including old/new writers, dirty data, resumable backfill and rollback limits. Verify relevant invariants and failures on safe data. Do not claim performance or zero downtime without evidence, or mutate production beyond authorization.
