# Choosing transaction boundaries

Read for concurrent check-and-change, invariants spanning records, explicit locking/isolation choices or transaction retries. Confirm engine, version and ORM behavior before relying on a particular guarantee.

Write the invariant in terms of committed state, then construct a conflicting execution: two actors observe an allowed state, both decide to change it, and both commit. Identify what must make one actor wait, fail or reconsider. A transaction around each actor is not itself an explanation.

Choose the least complex sufficient mechanism, combining these when needed:

- A durable constraint can reject invalid state from all writers; map violations to the operation's error contract.
- For a known row transition, consider an atomic conditional write and inspect its result. A predicate must include the relevant precondition; an affected-row count is not automatically evidence of why a write failed.
- Optimistic version checks need every relevant writer to participate and an explicit conflict policy. Never overwrite a newer value with a stale retry.
- Locks need a common protocol, bounded duration and consistent acquisition order. Locking returned rows may not protect an absent row or a predicate against insertion; establish the engine's actual behavior.
- A set-wide invariant may require a shared serialization point or stronger isolation. Explain which concurrent execution it prevents; avoid choosing an isolation label by habit.

For a serialization failure, repeat the whole transaction, including reads and decisions, with bounded attempts. Keep stable logical operation identity. Do not blindly retry business rejections or all constraint violations. Remote effects performed inside a retried callback can repeat; move them behind an appropriate durable handoff or provider idempotency/reconciliation contract.

Test the conflicting schedule through the real boundary where feasible, using synchronization rather than hoping a sleep produces a race. Also check permitted sequential behavior. A single-process mock does not demonstrate database isolation.

PostgreSQL examples and guarantees: [transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html), [complete-transaction retries](https://www.postgresql.org/docs/current/mvcc-serialization-failure-handling.html). These are engine-specific references, not guarantees for every database.
