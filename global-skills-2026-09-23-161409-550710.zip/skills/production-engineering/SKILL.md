---
name: production-engineering
description: Prepare, assess or change deployment, runtime configuration, lifecycle and operational readiness, including Kubernetes and GitOps. Excludes ordinary application edits and active incident triage without deployment work.
---

# Production engineering

Inspect the existing release path, configuration, runtime dependencies and operational ownership. Improve the existing platform and delivery model. Adopt GitOps, containers, orchestration or a replacement pipeline only when adoption or migration is part of the user's requested scope; a request to improve reliability or deployment does not imply a migration.

For changes to Kubernetes workloads (including Helm/Kustomize, probes or rollouts), read [kubernetes.md](kubernetes.md). For existing GitOps-managed deployment state or explicitly requested GitOps adoption, read [gitops.md](gitops.md). Load only the references the change needs.

Define startup, readiness, liveness, shutdown and recovery behavior. Readiness should reflect the ability to accept required work; liveness should not create restart cascades during a dependency outage. Drain traffic and bound in-flight work during termination, releasing resources and preserving durable jobs.

Keep configuration validated, secrets separated from code/logs, privileges minimal and resource usage bounded. Make failure and degradation observable through relevant logs, metrics and traces without leaking sensitive data or creating unbounded cardinality.

Plan compatibility while old and new versions overlap, including stored data, contracts and background jobs. Separate deployment from irreversible activation when helpful. Define rollout observations, success/failure thresholds based on known service expectations, and a recovery path. Do not invent numeric SLOs.

Rollback code only when it remains compatible with current state. Data migration and external effects may need roll-forward or validated restoration; a previous binary is not a universal undo. Identify backup and restore requirements proportionate to the actual risk.

Verify available build/config checks and lifecycle behavior in a safe environment. State what cannot be exercised locally. Preparation and a reviewable deployment plan do not grant permission to deploy, rotate secrets, incur infrastructure cost or alter live traffic.
