# GitOps changes

Read when GitOps reconciliation already owns deployment state or the user explicitly requests adopting it. Do not turn ordinary CI/CD improvements into a GitOps migration. Within that scope, trace the actual source: repository/revision, generated manifests, overlays, parameters and parent controllers. Change the authoritative input rather than a generated child that will be overwritten.

Separate artifact production from desired-state promotion and reconciliation. Use identifiable artifacts and inspect the rendered diff for the target environment. A merge or successful sync is not proof that the application is healthy or that a migration completed correctly.

Inspect pruning, self-healing, ownership/finalizers and deletion propagation before changes that can remove resources. Reconciliation can undo an emergency live patch; when such a patch is authorized, coordinate its lifetime and reconciliation back into the source of truth. Do not impose an unconditional ban on emergency operations or disable controllers merely for convenience.

Plan ordering and compatibility for dependencies, jobs, CRDs and data migrations when affected. Reverting Git cannot necessarily undo stored-data changes or external effects. Verify both controller convergence and the relevant workload outcome within the authorized scope.

References: [Argo CD automated sync](https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/), [deletion](https://argo-cd.readthedocs.io/en/stable/user-guide/app_deletion/). Other controllers have their own contracts.
