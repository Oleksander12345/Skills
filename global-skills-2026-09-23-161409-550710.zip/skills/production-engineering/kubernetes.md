# Kubernetes workload decisions

Read for Kubernetes workload, Helm/Kustomize rendering, probes, resources or rollout changes. Establish the cluster/API versions, controller, rendered manifests and application lifecycle; editing a template does not prove the deployed configuration.

Choose each probe for its consequence. Readiness controls whether an instance receives service traffic; liveness requests restart for a condition restart can remedy. A shared dependency outage should not blindly trigger restart cascades. A startup probe can give legitimate initialization time before the other probes run. Do not add all three without a need, or invent timing thresholds without workload evidence.

During termination, account for traffic draining, application signal handling, in-flight requests/jobs and the total grace period, including hooks. A delay alone is not proof of clean shutdown. Check whether retries elsewhere can repeat interrupted work.

Relate requests to scheduling/capacity and limits to runtime constraints. Choose scaling signals from the bottleneck; adding replicas cannot fix every saturated dependency. Review rollout surge/unavailability against spare capacity and state compatibility. A disruption budget concerns eligible voluntary disruptions; it does not guarantee availability for every failure or control a Deployment's rolling-update strategy.

Inspect service identity, RBAC, configuration/secrets and persistent-state implications only where changed. Verify rendering/schema checks and the relevant lifecycle behavior in an authorized environment. Successful manifest validation is not successful rollout or restored user traffic.

References: [probes](https://kubernetes.io/docs/concepts/workloads/pods/probes/), [termination](https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#pod-termination), [disruptions](https://kubernetes.io/docs/concepts/workloads/pods/disruptions/). Check current platform/version details before applying them.
