---
name: browser-e2e
description: Reproduce or verify an interactive user journey in an available browser, especially persistence, navigation and integration failures. Excludes copy-only edits, backend-only changes and requests without a browser task.
---

# Browser journey verification

Select the smallest user journey that distinguishes success from the reported failure. Establish the target environment, test identity and safe data. Follow existing browser tooling and project tests; do not introduce a new automation stack without a concrete need.

Observe initial state, perform realistic user actions and assert user-visible outcomes. For persistence claims, verify after refresh or a new relevant session rather than trusting a success toast. Test a meaningful error or interruption when it could break the changed flow. Use accessible roles and stable identifiers where supported; avoid brittle coordinates unless the available tool requires them.

Inspect network responses, console errors, DOM state and server-side evidence when available to explain a discrepancy. A successful HTTP response does not by itself prove the right state was saved, and a screenshot does not prove all interactions work. Record enough evidence to reproduce the result without exposing tokens or private data.

Check keyboard access, focus and basic responsive behavior when affected. Wait on actual observable conditions rather than arbitrary long sleeps. Keep tests isolated and repeatable; avoid sharing mutable test records across concurrent runs. Cleanup only test data created for the authorized run.

Do not submit purchases, contact real users, delete data or change production state merely to verify a flow. If access is missing, report the precise limitation and an executable verification outline. Never claim an unexecuted journey passed. Do not run a full E2E suite for a static typo.
