---
name: messaging-event-driven
description: Implement or change durable messaging, event consumers, replay and delivery contracts. Excludes introductory data-structure questions and unrelated application changes.
---

# Messaging and event-driven work

Establish whether a message is a command, a fact or a notification; identify its owner, consumers, durability needs and ordering scope. Choose queue, log or publish/subscribe behavior from these requirements, not a preferred broker.

Define acknowledgement and state-commit boundaries. Acknowledge after required work is durable; acknowledge-before-write can lose work. Crash after commit but before acknowledgement causes redelivery. Make processing idempotent with appropriately scoped stable identity and atomic deduplication plus state change where supported. External effects need their own idempotency or reconciliation; local deduplication alone does not make them atomic.

For database writes coupled to publication, identify the dual-write failure window and choose a recoverable handoff consistent with the existing system. Do not prescribe an outbox when no such boundary exists. Preserve per-entity ordering where required without assuming global order.

For state/publication handoff, transactional consumers or external effects during processing, read [reliable-handoff.md](reliable-handoff.md).

Bound in-flight work, retries and backlogs. Distinguish transient failures from poison messages, validate payloads, and define observable quarantine/dead-letter handling and ownership of recovery. A dead-letter queue is not successful processing.

Specify schema evolution, unknown-field/version handling and replay compatibility. Replaying history must not repeat irreversible external effects accidentally. Define dedup retention and how corrections or new versions affect operation identity.

Test duplicate delivery, crashes around commit/ack, out-of-order inputs and incompatible messages when relevant. Report actual guarantees and unsupported cases. Do not purge, replay or redrive live messages without authorization for those effects.
