# Reliable handoff across durable boundaries

Read when a state change must cause publication, message processing changes durable state, or a consumer invokes an external effect. First establish the required delivery and recovery behavior; best-effort work does not automatically need a durable protocol.

List the participants and the actual atomic boundary. For each ordering of state commit, publish and acknowledgement, identify the crash that loses work or repeats an effect. Use the existing recoverable mechanism when it meets the contract; outbox, CDC and durable workflow facilities are alternatives with different assumptions.

For an outbox, persist business state and publication intent atomically. Give each logical event a stable identity distinct from a relay attempt. A relay can publish successfully and crash before recording success, so its next attempt may publish again. Make claims recoverable after worker death, bound batches/retries, and make backlog age and exhausted retries observable. Neither a claim lease nor broker acknowledgement proves an external business effect happened exactly once.

For a transactional consumer, deduplication and the protected local state change must commit together. Recording “processed” first can lose the effect; recording it later in a separate transaction can repeat it. Concurrent duplicates need durable uniqueness/conflict handling. A payment, email or other remote effect is outside that local transaction: use the receiver's idempotency contract or an explicit reconciliation state machine, preserving identity across retries.

Define ordering only over the required entity/partition scope. Parallel relays and retries can change order; timestamps alone are not an ordering protocol. State what happens to stale versions, poison messages and replay after deduplication records expire. Cleanup must respect the replay/recovery window rather than silently weakening guarantees.

Verify crashes on both sides of each commit/ack boundary and a concurrent duplicate where relevant. Assert durable state and downstream effects, not merely that the handler returned success. Report the boundary within which any exactly-once claim holds.

[AWS transactional outbox guidance](https://docs.aws.amazon.com/prescriptive-guidance/latest/cloud-design-patterns/transactional-outbox.html) describes atomic intent and duplicate delivery; use actual broker/database contracts for the implementation.
