---
name: feature-design
description: Design nontrivial product features with unresolved requirements or multiple affected components. Excludes cosmetic edits, obvious local fixes, and executing an already agreed plan.
---

# Feature design

Read the relevant flow, callers, project conventions, and existing helpers before choosing a solution. Start with the user's outcome and the smallest change that achieves it.

Separate known requirements from assumptions. Resolve acceptance behavior, permissions, important failure cases, and meaningful performance or compatibility constraints. Ask only questions whose answers change the implementation; continue independent work while waiting. Never manufacture a requirement for a formal design approval.

Make domain invariants, responsibility boundaries and the source of truth explicit where they affect the feature. Prefer a cohesive flow over speculative layers; estimate complexity from interacting states and failure paths, not class counts.

Compare alternatives only where a real trade-off exists. Reuse existing capabilities before adding infrastructure. Check boundary cases in the actual flow: empty input, partial failure, repeated requests, tenant boundaries, or large result sets as relevant. Do not enumerate unrelated risks.

For substantial changes, make a compact executable plan: affected modules, dependency order, relevant tests, compatibility or migration steps, and evidence required to finish. Find actual paths before naming files; label hypothetical paths. A small feature can need only a paragraph. Do not create planning documents unless requested or useful for durable coordination.

When implementation is authorized, proceed after resolving blocking requirements. A design response alone does not complete a build request. Preserve the user's chosen stack and scope. Do not automatically invoke architecture, planning, or review skills as a chain.
