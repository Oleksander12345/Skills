---
name: performance-review
description: Investigate measured latency, throughput, memory or scaling problems, or review a change with a concrete performance risk. Excludes speculative optimization and ordinary small changes.
---

# Performance review

Define the user-visible symptom, workload and performance budget. Separate measured facts from estimates. Establish a reproducible baseline with representative data size, concurrency, cache state and environment; use tail latency as well as averages where relevant.

Attribute time and resource use before changing code. Examine computation, I/O waits, query plans and counts, network calls, serialization, allocation, rendering, contention and queueing as the path warrants. Avoid running an exhaustive checklist unrelated to the symptom.

Use time and space complexity to identify growth, but connect asymptotic claims to actual input sizes and constants. A nominally linear operation can allocate too much or block critical work; a small bounded quadratic operation need not justify a rewrite. Bound buffers, fan-out and concurrency.

Investigate the largest supported bottleneck first. Prefer a focused correction over a stack rewrite. Caching requires an ownership, key, invalidation, staleness and memory policy; it must preserve permissions and correctness. Adding concurrency can worsen pool exhaustion and contention.

Compare before and after under matched conditions. Repeat noisy measurements enough to distinguish signal within the available budget; include correctness and resource regressions. Do not claim improvement from intuition, one favorable sample or a microbenchmark unrelated to the user flow.

Report evidence, the change, trade-offs and remaining bottlenecks. Do not load-test production, generate bills or change live capacity without authorization. If measurements are unavailable, provide a concrete measurement plan and label any proposed optimization as a hypothesis.
